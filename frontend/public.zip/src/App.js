import Routing from "./Routes/Routing";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
      <Routing />
  );
}

export default App;
